<?php namespace CodeIgniter\Log\Handlers;

use Tests\Support\Config\MockLogger as LoggerConfig;
use Tests\Support\Log\Handlers\MockChromeHandler;
use CodeIgniter\Services;

class ChromeLoggerHandlerTest extends \CIUnitTestCase
{

	public function testCanHandleLogLevel()
	{
		$config                                                              = new LoggerConfig();
		$config->handlers['CodeIgniter\Log\Handlers\TestHandler']['handles'] = ['critical'];

		$logger = new ChromeLoggerHandler($config->handlers['CodeIgniter\Log\Handlers\TestHandler']);
		$this->assertFalse($logger->canHandle('foo'));
	}

	//--------------------------------------------------------------------

	public function testHandle()
	{
		$config                                                              = new LoggerConfig();
		$config->handlers['CodeIgniter\Log\Handlers\TestHandler']['handles'] = ['critical'];

		$logger = new ChromeLoggerHandler($config->handlers['CodeIgniter\Log\Handlers\TestHandler']);
		$this->assertTrue($logger->handle('warning', 'This a log test'));
	}

	//--------------------------------------------------------------------

	public function testSendLogs()
	{
		$config                                                              = new LoggerConfig();
		$config->handlers['CodeIgniter\Log\Handlers\TestHandler']['handles'] = ['critical'];

		$logger = new ChromeLoggerHandler($config->handlers['CodeIgniter\Log\Handlers\TestHandler']);
		$logger->sendLogs();

		$response = Services::response(null, true);

		$this->assertTrue($response->hasHeader('X-ChromeLogger-Data'));
	}

	//--------------------------------------------------------------------

	public function testSetDateFormat()
	{
		$config                                                              = new LoggerConfig();
		$config->handlers['CodeIgniter\Log\Handlers\TestHandler']['handles'] = ['critical'];

		$logger = new ChromeLoggerHandler($config->handlers['CodeIgniter\Log\Handlers\TestHandler']);
		$result = $logger->setDateFormat('F j, Y');

		$this->assertObjectHasAttribute('dateFormat', $result);
		$this->assertObjectHasAttribute('dateFormat', $logger);
	}

	//--------------------------------------------------------------------

	public function testObjectMessage()
	{
		$config                                                              = new LoggerConfig();
		$config->handlers['CodeIgniter\Log\Handlers\TestHandler']['handles'] = ['critical'];

		$logger            = new MockChromeHandler($config->handlers['CodeIgniter\Log\Handlers\TestHandler']);
		$data              = new \stdClass();
		$data->code        = 123;
		$data->explanation = "That's no moon, it's a pumpkin";
		$result            = $logger->setDateFormat('F j, Y');

		$logger->handle('debug', $data);
		$peek = $logger->peekaboo();

		$this->assertEquals($data->explanation, $peek[0]['explanation']);
	}

}
