<nav class="navbar navbar-expand-lg navbar-light bg-light">
    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarSupportedContent">
        <ul class="navbar-nav mr-auto">
            <li class="nav-item active">
                <a class="nav-link" href="#"><h2><?= $title ?></h2><span class="sr-only">(current)</span></a>
            </li>
        </ul>
    </div>
    <a href='javascript:self.history.back();' class="btn btn-success float-right" role="button">Go Back</a>
</nav>

<div class="row">
    <div class="col-md-12">
        <?php foreach($errors as $error): ?>
            <div class="alert alert-danger" role="alert">
                <?= $error ?>
            </div>
        <?php endforeach ?>      
        <form name="addform" action="<?= site_url('add') ?>" method="POST">
            <div class="form-group">
                <label for="name">LGU Name:</label>
                <input type="text" class="form-control" id="name" name="name" placeholder="Enter a Local Government Unit" required>
            </div>
            <div class="form-group">
                <label for="province">Province:</label>
                <input class="form-control" type="text" id="province" name="province" placeholder="Enter a province" required>
            </div>
            <div class="form-group">
                <label for="map">Link to photo:</label>
                <input class="form-control" type="text" id="map" name="map"  placeholder="Enter a map photo URL" required>
            </div>
            <div>     
                <label for="type">LGU Type:</label><br>
                    <div class="form-check-inline">
                        <label class="form-check-label">
                            <input type="radio" class="form-check-input" name="type" value="City" checked>City
                        </label>
                    </div>
                    <div class="form-check-inline">
                        <label class="form-check-label">
                            <input type="radio" class="form-check-input" name="type" value="Municipality">Municipality
                        </label>
                    </div>
            </div>
            <br>
            <div>     
                <label for="region">Region:</label><br>
                    <select class="drop-down-region" type="text" name="region" required>
                        <option value="">Select Region</option>
                        <option value="NCR">NCR</option>
                        <option value="Region 1">Region 1</option>
                        <option value="Region 2">Region 2</option>
                        <option value="Region 3">Region 3</option>
                        <option value="Region 4-A">Region 4-A</option>
                        <option value="Region 4-B">Region 4-B</option>
                        <option value="Region 5">Region 5</option>
                        <option value="Region 6">Region 6</option>
                        <option value="Region 7">Region 7</option>
                        <option value="Region 8">Region 8</option>
                        <option value="Region 9">Region 9</option>
                        <option value="Region 10">Region 10</option>
                        <option value="Region 11">Region 11</option>
                        <option value="Region 12">Region 12</option>
                        <option value="Region 13">Region 13</option>
                        <option value="CAR">CAR</option>
                        <option value="BARMM">BARMM</option>
                    </select>
            </div>
            <br>
            <button type="submit" class="btn btn-primary float-right">Save</button>
        </form>
    </div>
</div>