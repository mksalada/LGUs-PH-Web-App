<nav class="navbar navbar-expand-lg navbar-light bg-light">
    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
    </button>

    <div class="collapse navbar-collapse" id="navbarSupportedContent">
        <ul class="navbar-nav mr-auto">
            <li class="nav-item active">
                <a class="nav-link" href="<?= base_url() ?>"><h2><?= $title ?></h2><span class="sr-only">(current)</span></a>
            </li>
        </ul>
        <div class="row">
            <form class="form-inline" role="form" action="<?= site_url() ?>" method="GET">
                <div class="form-group">
                    <input type="text" class="form-control" name="query" placeholder="Search LGU in Luzon only" required>
                    <select class="form-control" id="FormControlSelect1" name="field" required>
                    <option value="">Select field</option>
                        <option value="name">LGU Name</option>
                        <option value="province">Province</option>
                        <option value="type">LGU Type</option>
                        <option value="region">Region</option>
                    </select>
                </div>
                <button type="submit" class="btn btn-warning" name="submit" >Search</button>
            </form>
        </div>
    </div>
</nav><br>

<div class="row">
    <div class="col-md-12">
        <div class="container-responsive">
            <div class="row">
                <div class="col-md-8" style="color: #bbb;">
                    <caption><?= "About $count results ($time seconds) requested by $ip" ?></caption>
                </div>
                <div>
                    <a href="<?= site_url('add') ?>" class="btn btn-success float-right" style="position: relative; left: 196px; top: -2px; transition: none 0s ease 0s;" role="button" >Add New</a>
                </div>
            </div>
        </div><br>

        <div class="table-responsive-sm">
            <table class="table">
                <thead class="bg-light">
                    <th>ID</th>
                    <th>LGU Name</th>
                    <th>Province</th>
                    <th>LGU Type</th>
                    <th>Region</th>
                    <th>Modify</th>
                    <th>Remove</th>
                </thead>
                <?php if(!empty($lgus) && is_array($lgus)): ?>
                    <?php foreach ($lgus as $name): ?>
                        <tr>
                            <td>
                                <a href="<?= site_url('info/').$name['id'] ?>" class="btn btn-secondary" role="button"><?= $name['id'] ?></a>    
                            </td>
                            <td>
                                <?= $name['name'] ?>   
                            </td>
                            <td>
                                <?= $name['province'] ?>
                            </td>
                            <td>
                                <?= $name['type'] ?>
                            </td>
                            <td>
                                <?= $name['region'] ?>
                            </td>
                            <td><a href="<?= site_url('edit')."/".$name['id'] ?>" role="button" class="btn btn-primary float-right">Edit</a> </td>
                            <td><a href="<?= site_url('delete')."/".$name['id'] ?>" onClick="return confirm('Are you sure you want to delete this record?')" role="button" class="btn btn-danger">Delete</a> </td>
                        </tr> 
                    <?php endforeach; ?>
                <?php endif; ?>
            </table>
        </div>
    </div>
</div>
<div class="row">
    <div class="col-md-12">
        <div class="container bg-light">
            <?= $pager->links() ?>
        </div>
    </div>
</div>