    <div class="row">
        <div class="col-md">
            <?php if (! empty($lgus)) : ?>
            <div class="card" style="width: 24rem;">
                <img src="<?= $lgus['map'] ?>" class="card-img-top" alt="<?= $lgus['name']." map" ?>">
                <div class="card-body">
                    <h5 class="card-title"><?= $lgus['name'] ?></h5>
                    <p class="card-text"><a
                            href="<?= site_url()."/?query=".trim($lgus['province']."&field=province") ?>"><?= $lgus['province'] ?></a>
                    </p>
                </div>
                <ul class="list-group list-group-flush">
                    <li class="list-group-item"><b>ID</b> : <small><?= $lgus['id'] ?></small></li>
                    <li class="list-group-item"><b>LGU Type</b> : <a
                            href="<?= site_url()."/?query=".trim($lgus['type']."&field=type") ?>"><?= $lgus['type'] ?></a>
                    </li>
                    <li class="list-group-item"><b>Region</b> : <a
                            href="<?= site_url()."/?query=".trim($lgus['region']."&field=province") ?>"><?= $lgus['region'] ?></a>
                    </li>
                </ul>
                <div class="card-body">
                    <a href="javascript:self.history.back();" class="btn btn-secondary float-right btn-sm">Back</a>
                </div>
            </div>
            <?php else : ?>
            <div class="card" style="width: 25rem;">
                <img src="#" class="card-img-top" alt="...">
                <div class="card-body">
                    <h5 class="card-title">Unknown</h5> <!-- LGU Name -->
                    <p class="card-text"><a href="#">Unknown</a></p> <!-- Province -->
                </div>
                <ul class="list-group list-group-flush">
                    <li class="list-group-item"><b>ID</b> : <small>Unknown</small></li>
                    <li class="list-group-item"><b>LGU Type</b> : Unknown</a></li>
                    <li class="list-group-item"><b>Region</b> : Unknown</a></li>
                </ul>
                <div class="card-body">
                    <a href="javascript:self.history.back();" class="btn btn-secondary float-right btn-sm">Back</a>
                </div>
            </div>
            <?php endif ?>
        </div>
    </div>