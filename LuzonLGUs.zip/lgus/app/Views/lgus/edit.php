<nav class="navbar navbar-expand-lg navbar-light bg-light">
    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent"
        aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
    </button>

    <div class="collapse navbar-collapse" id="navbarSupportedContent">
        <ul class="navbar-nav mr-auto">
            <li class="nav-item active">
                <a class="nav-link" href="#">
                    <h2><?= $title ?></h2><span class="sr-only">(current)</span>
                </a>
            </li>
        </ul>
    </div>
    <a href='javascript:self.history.back();' class="btn btn-success float-right" role="button">Go Back</a>
</nav>

<div class="row">
    <div class="col-md-12">

        <?php foreach($errors as $error): ?>
        <div class="alert alert-danger" role="alert">
            <?= $error ?>
        </div>
        <?php endforeach ?>

        <form name="addform" action="<?= site_url('edit') ?>" method="POST">
            <div class="form-group">
                <label for="name">Name:</label>
                <input type="text" class="form-control" id="name" name="name" value="<?= $lgus['name'] ?>" required>
            </div>

            <div class="form-group">
                <label for="province">Province:</label>
                <input class="form-control" type="text" id="province" name="province" value="<?= $lgus['province'] ?>"
                    required>
            </div>

            <div>
                <label for="type">LGU Type:</label><br>
                <div class="form-check-inline">
                    <label class="form-check-label">
                        <input type="radio" class="form-check-input" name="type" value="City"
                            <?= $result=($lgus['type']=="City"?"checked":"") ?>>City
                    </label>
                </div>

                <div class="form-check-inline">
                    <label class="form-check-label">
                        <input type="radio" class="form-check-input" name="type" value="Municipality"
                            <?= $result=($lgus['type']=="Municipality"?"checked":"") ?>>Municipality
                    </label>
                </div>
            </div>
            <br>
            <div>
                <label for="region">Region:</label><br>
                <select class="drop-down-region" type="text" name="region" required>
                    <option value="">Select Region</option>
                    <option value="NCR" <?= $result=($lgus['region']=="NCR"?"selected":"") ?>>NCR</option>
                    <option value="Region 1" <?= $result=($lgus['region']=="Region 1"?"selected":"") ?>>Region 1</option>
                    <option value="Region 2" <?= $result=($lgus['region']=="Region 2"?"selected":"") ?>>Region 2</option>
                    <option value="Region 3" <?= $result=($lgus['region']=="Region 3"?"selected":"") ?>>Region 3</option>
                    <option value="Region 4-A" <?= $result=($lgus['region']=="Region 4-A"?"selected":"") ?>>Region 4-A</option>
                    <option value="Region 4-B" <?= $result=($lgus['region']=="Region 4-B"?"selected":"") ?>>Region 4-B</option>
                    <option value="Region 5" <?= $result=($lgus['region']=="Region 5"?"selected":"") ?>>Region 5</option>
                    <option value="Region 6" <?= $result=($lgus['region']=="Region 6"?"selected":"") ?>>Region 6</option>
                    <option value="Region 7" <?= $result=($lgus['region']=="Region 7"?"selected":"") ?>>Region 7</option>
                    <option value="Region 8" <?= $result=($lgus['region']=="Region 8"?"selected":"") ?>>Region 8</option>
                    <option value="Region 9" <?= $result=($lgus['region']=="Region 9"?"selected":"") ?>>Region 9</option>
                    <option value="Region 10" <?= $result=($lgus['region']=="Region 10"?"selected":"") ?>>Region 10</option>
                    <option value="region 11" <?= $result=($lgus['region']=="Region 11"?"selected":"") ?>>region 11</option>
                    <option value="Region 12" <?= $result=($lgus['region']=="Region 12"?"selected":"") ?>>Region 12</option>
                    <option value="Region 13" <?= $result=($lgus['region']=="Region 13"?"selected":"") ?>>Region 13</option>
                    <option value="CAR" <?= $result=($lgus['region']=="CAR"?"selected":"") ?>>CAR</option>
                    <option value="BARMM" <?= $result=($lgus['region']=="BARMM"?"selected":"") ?>>BARMM</option>
                </select>
            </div>
            <br>
            <div class="form-group">
                <label for="map">Link to the Map photo :</label>
                <input class="form-control" type="text" id="map" name="map" value="<?= $lgus['map'] ?>">
            </div>
            <br>
            <input type="hidden" value="<?= $lgus['id'] ?>" name="id">
            <button type="submit" class="btn btn-primary float-right">Update</button>
        </form>
    </div>
</div>