<?php namespace App\Controllers;

use App\Models\LgusModel;

class Lgus extends BaseController
{

// INDEX
	public function index()
	{
		$pager = \Config\Services::pager();
		$request = \Config\Services::request();
		$model = new LgusModel();
		$builder = $model->builder();
		$query = $request->getGET('query');
		$field = $request->getGET('field');

		if(!empty($query) && !empty($field))
		{
			$time_pre = microtime(true);
			$result = $model->search($builder, $query, $field);
			$time_post = microtime(true);
			$exec_time = $time_post - $time_pre;

			$data = [
				'title' => 'Local Government Units',
				'lgus' => $result,
				'count' => $pager->getPageCount()>1?$pager->getPageCount()*7:"less than 7",
				'time' => $exec_time,
				'query' => $query,
				'field' => $field,
				'ip' => $_SERVER['HTTP_HOST'],
			];
		}
		else
		{
			$time_pre = microtime(true);
			$result = $model->getAllNames($builder);
			$time_post = microtime(true);
			$exec_time = $time_post - $time_pre;

			$data = [
				'title' => 'Local Government Units',
				'lgus' => $result,
				'count' => $pager->getPageCount()>1?$pager->getPageCount()*7:"less than 7",
				'time' => $exec_time,
				'query' => $query,
				'field' => $field,
				'ip' => $_SERVER['HTTP_HOST'],
			];
		}
		$data += ['pager' => $pager];

		echo view('templates/header');
		echo view('lgus/content',$data);
		echo view('templates/footer');
	}

// INFO
	public function info($id=null)
	{
		$dbConnect = new LgusModel();

		$data = [
			'title' => 'Local Government Unit',
			'lgus' => $dbConnect->getName($id),
		];
		echo view('templates/header');
		echo view('lgus/info',$data);
		echo view('templates/footer');
	}

// DELETE
	public function delete($id=null)
	{
		$dbConnect = new LgusModel();

		if($id==null || empty($id))
			return redirect()->to(site_url());

		try {
			$dbConnect->delete($id);
		} catch (\Exception $e) {
			die($e->getMessage());
		}
		return redirect()->to(\site_url());
	}

// EDIT
	public function edit($id=null)
	{
		$dbConnect = new LgusModel(); // dbConnect = former variable name = lgus
		$request = \Config\Services::request();
		$validation = \Config\Services::validation();

		$id = $id==null ? $_REQUEST['id'] : $id;

		if($_SERVER["REQUEST_METHOD"]=="POST")
		{
			if( $this->validate([
				'id' => 'required',
				'name' => 'required',
				'province' => 'required',
				'type' => 'required',
				'region' => 'required',
				'map' => 'required',
			]))
			{
				$newName=[
					'name'=>$request->getPost('name'),
					'province'=>$request->getPost('province'),
					'type'=>$request->getPost('type'),
					'region'=>$request->getPost('region'),
					'map'=>$request->getPost('map'),
				];

				try {
					$result = $dbConnect->update($request->getPost('id'),$newName);
				} catch (\Exception $e) {
					die($e->getMessage());
				}
	
				return redirect()->to(\site_url());
			};
		}

		$data = [
			'id' => $id,
			'title' => 'Edit a Local Government Unit',
			'lgus' => $dbConnect->getName($id),
			'errors' => $validation->getErrors(),
		];

		echo view('templates/header');
		echo view('lgus/edit',$data);
		echo view('templates/footer');
	}

// ADD
	public function add()
	{
		$validation = \Config\Services::validation();
		$request = \Config\Services::request();

		if( $_SERVER["REQUEST_METHOD"] == "POST")
		{
			if( $this->validate([
				'name' => 'required',
				'province' => 'required',
				'type' => 'required',
				'region' => 'required',
				'map' => 'required',
			]))
			{
				$newName = [
					'name' => $request->getPost('name'),
					'province' => $request->getPost('province'),
					'type' => $request->getPost('type'),
					'region' => $request->getPost('region'),
					'map' => $request->getPost('map'),
				];

				$dbConnect = new LgusModel();
				try {
					$result = $dbConnect->insert($newName);
				} catch (\Exception $e) {
					die($e->getMessage());
				}

				return redirect()->to(site_url());
			}
		}

		$data = [
			'title' => 'Add new Local Government Unit',
			'errors' => $validation->getErrors(),
		];
		echo view('templates/header');
		echo view('lgus/add',$data);
		echo view('templates/footer');
	}

}